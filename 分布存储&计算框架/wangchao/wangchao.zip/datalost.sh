#!/bin/bash

# 记录文件位置
record="/home/dsjxtjc/2018211150/data_2/record"

# 获取待检查主机
serve=$1

# 获取列表
flist="/home/dsjxtjc/2018211150/data_2/flist"
echo $2 > $flist
echo "文件列表"
cat $flist

# 检查该主机应有的chunk数
temp_exam_serv="/home/dsjxtjc/2018211150/data_2/temp_exam_serv"
grep "$serve" $record | awk -F ' ' '{print $2}' > $temp_exam_serv

# 查找主机丢失数据
temp_lst="/home/dsjxtjc/2018211150/data_2/temp_lst"
comm -23 <(sort $temp_exam_serv|uniq ) <(sort $flist|uniq) > $temp_lst

# chunk恢复
temp_file="/home/dsjxtjc/2018211150/data_2/temp_file"
num=$(cat $temp_lst | wc -l)
echo "########"
echo $num
if [ $num -ne 0 ];then
   cat $temp_lst | while read line
   do
     sour=$(grep "$line" $record | grep -v "$serve" | head -n 1 | awk -F ' ' '{print $3}')
     echo $sour
     aim=$(grep "$line" $record | grep "$serve" | awk -F ' ' '{print $3}')
     scp $sour $temp_file
     scp $temp_file $aim
   done
fi
    
# 删除临时文件
rm $temp_file
rm $temp_exam_serv
rm $temp_lst
rm $flist
