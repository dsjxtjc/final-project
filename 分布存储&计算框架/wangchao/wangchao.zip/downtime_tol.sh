#!/bin/bash

# 用以产生随机数选择复制文件到哪个serve上
function randn(){
    touch ./temp
    rm ./temp
    touch ./temp

    while true
    do
    c="thumm0""$(($RANDOM%4+2))"
    a=$(grep "$c" $1 | wc -l)
    echo $a
    echo $c
    if [ $a -eq 0 ] ; then
        echo $c > /home/dsjxtjc/2018211150/data_2/temp_randn_serve
        break
    fi
    done
}

# 传入宕机服务器编号
#serve="thumm0"$1
serve=$1
# DFS记录文件的绝对地址
record="/home/dsjxtjc/2018211150/data_2/record"
loc="/home/dsjxtjc/2018211150/data_2/"
temp_sev="/home/dsjxtjc/2018211150/data_2/temp_sev"
temp_chgrec="/home/dsjxtjc/2018211150/data_2/temp_chgrec"
temp_err_tol="/home/dsjxtjc/2018211150/data_2/temp_err_tol"
# 查询宕机服务器上的chunk信息
grep "$serve" $record > $temp_err_tol

# 查询该服务器上chunk的其他存储位置，得到文件temp_cor_sev
cat $temp_err_tol | while read line
do
chunk=$(echo $line | awk -F ' ' '{print $2}')   # chunk信息
grep "$chunk" $record | grep -v "$serve" > $temp_sev
echo $line >> $temp_sev

# 得到待发送文件服务器
randn $temp_sev
echo "#####"
cor_serve=$(cat "$loc""temp_randn_serve")
echo "#########"
echo $cor_serve

# 得到需发送文件
block_cor=$(cat $temp_sev | head -n 1)
aimloc="$loc""$chunk"
scloc_total=$(echo $block_cor | awk -F ' ' '{print $3}')
scloc=$(echo $block_cor | awk -F ' ' '{print $5}')
echo $scloc_total
scp $scloc_total $aimloc
scp $aimloc "$cor_serve"":""$scloc"

# 删除thumm01上的文件数据
rm $aimloc

# 修改record文件
echo $line > $temp_chgrec
sed -i "s/$serve/$cor_serve/g" $temp_chgrec
#sed -i '/$line/d' $record
sed -i "/$(sed 's#/#\\/#g'<<<$line)/d" $record
cat $temp_chgrec | head -n 1 >> $record
done

# 删除临时文件
rm $temp_chgrec
rm $temp_sev
rm "$loc""temp_randn_serve"
rm $temp_err_tol

