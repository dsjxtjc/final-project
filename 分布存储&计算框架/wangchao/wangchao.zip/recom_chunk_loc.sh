#!/bin/bash
# 主机数目
num=5
# 
temp_sev_block="/home/dsjxtjc/2018211150/data_2/temp_sev_block"
recom_chunk="/home/dsjxtjc/2018211150/data_2/recom_chunk.txt"

for (( i=2;i<=$num;i++ ))
do

    serve="thumm0"$i
    ssh $serve ls -h /data/dsjxtjc/2018211150/*.txt | awk -F '/' '{print $5}' | awk -F '.' '{print $1}' | grep -v "goal" > $temp_sev_block"$i"
    ssh $serve rm /data/dsjxtjc/2018211150/*.txt
    ssh $serve rm /data/dsjxtjc/2018211150/*.sh
    sed -i "s/$/ $serve/" $temp_sev_block"$i"
done
cat temp_sev_block* > $recom_chunk
#cat $recom_chunk > /dev/tcp/10.81.10.80/9527
#echo "finish" > /dev/tcp/10.81.10.80/9527
rm temp_sev_block*
