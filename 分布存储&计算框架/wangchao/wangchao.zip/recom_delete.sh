#!/bin/user

for (( i=2; i<=5; i=i+1 ))
do

	ssh "thumm0""$i" rm /data/dsjxtjc/2018211150/*.txt
done
