#!/bin/user
cat ./CF_project/* > ./total
cat ./total | sort -r | head -n $1 > ./neighbor
python ./reduce_recommand.py $2 $3 ./neighbor
rm ./total
rm ./neighbor
