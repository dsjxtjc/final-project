#!/usr/bin/env python
#coding:utf-8

import numpy as np
import sys
from texttable import Texttable

#个数
num=int(sys.argv[1])
#ratings文件地址
address_ratings=str(sys.argv[2])
#邻居文件地址
address_neighbors=str(sys.argv[3])

class reduces:
    # 找到某用户的相邻用户
    def __init__(self,movies,ratings,neighbors,n):
	self.movies=movies
        self.ratings=ratings
        self.neighbors=neighbors
        self.n=n
        self.userDict = {}
       	self.ItemUser = {} 
        # 推荐列表
        self.recommandList = []
    def recommand(self):
        self.formatRate()
        self.getrecommandList()
        return self.recommandList
    
    def getrecommandList(self):
        self.recommandList = []
        # 建立推荐字典
        recommandDict = {}
	#print "&&&&&&&&&"
	#print self.neighbors
        for neighbor in self.neighbors:
	    #print "$$$$$$$$$"
	    #print neighbor
            movies = self.userDict[neighbor[1]]
	    #print "*********"
	    #print movies
            for movie in movies:
                if(movie[0] in recommandDict):
                    recommandDict[movie[0]] +=float(neighbor[0])
                else:
                    recommandDict[movie[0]] = float(neighbor[0])
	#print recommandDict
        # 建立推荐列表
        for key in recommandDict:
            self.recommandList.append([recommandDict[key], key])
        self.recommandList.sort(reverse=True)
        self.recommandList = self.recommandList[:self.n]
	#print "#########"
	#print self.recommandList
	
    def formatRate(self):
        self.userDict = {}
        for i in self.ratings:
            temp = (i[1], float(i[2]) / 5)
            if(i[0] in self.userDict):
                self.userDict[i[0]].append(temp)
            else:
                self.userDict[i[0]] = [temp]
   
    # 显示结果
    def showTable(self):
        neighbors_id = [i[1] for i in self.neighbors]
        table = Texttable()
        table.set_deco(Texttable.HEADER)
        table.set_cols_dtype(["t","t","t","t"])
        table.set_cols_align(["l", "l", "1", "1"])
        rows = []
        
        rows.append([u"movie ID",u"movie name",u"movie type", u"from userID"])
        for item in self.recommandList:
            fromID = self.neighbors
            movie = []
            movie.append(item[1])
	    for i in self.movies:
	        if i[0]==str(item[1]):
		    movie.append(i[1])
		    movie.append(i[-1])
	    #movie.append(self.movies[int(item[1])])
            movie.append(fromID)
            rows.append(movie)
        table.add_rows(rows)
        print(table.draw())

def readRate(filename):
    files = open(filename)
    data = []
    for line in files.readlines():
        item = line.strip().split(",")
        data.append(item)
    return data

def readNeigh(filename):
    files = open(filename)
    data = []
    for line in files.readlines():
        item = line.strip().split(" ")
        data.append(item)
    return data

# 读取ratings数据
ratings=readRate(address_ratings)

# 读取电影信息
movies=readRate("/home/dsjxtjc/2018211150/data_2/movies.csv")
#print ratings[6]
neigh=readNeigh(address_neighbors)
#print neigh[3]
Reduce=reduces(movies,ratings,neigh,num)

recommandlist=Reduce.recommand()
#print recommandlist
print "\n\n\n\n"
print "Recommended list:"
Reduce.showTable()
print "\n\n\n\n\n\n"
np.savetxt("result_recommand.txt",np.array(recommandlist),fmt ='%s')
