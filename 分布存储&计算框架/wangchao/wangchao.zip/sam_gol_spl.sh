#!/bin/user
goal=$1
awk -F ',' '{if($1=="'$goal'"){print}}' $2>goal.txt
awk -F ',' '{if($1!="'$goal'"){print}}' $2>sample
