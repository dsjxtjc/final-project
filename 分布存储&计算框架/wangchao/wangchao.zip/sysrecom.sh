#!/bin/user
whiptail --title "Recommendation System" --yes-button "Continue" --no-button "Cancel"  --yesno "This program is used to recommend movies to users." 10 60
if [ $? -eq 0 ];then
    # 输入参数
    fileloc=$(whiptail --title "Input Box" --inputbox "Please enter the absolute address of the film evaluation data" 10 60 3>&1 1>&2 2>&3)
    whiptail --title "Prompt" --msgbox "Save the data file to the DFS" 10 60
    block=$(whiptail --title "Input Box" --inputbox "Please enter the chunk size" 10 60 3>&1 1>&2 2>&3)
    rep=$(whiptail --title "Input Box" --inputbox "Please enter the copy number" 10 60 3>&1 1>&2 2>&3)
    whiptail --title "Prompt" --msgbox "Choose the parameters of recommendation algorithm" 10 60
    id=$(whiptail --title "Input Box" --inputbox "Please choose which user to recommend to the product(User ID)" 10 60 3>&1 1>&2 2>&3)
    neighbor=$(whiptail --title "Input Box" --inputbox "Please select the number of neighbors" 10 60 3>&1 1>&2 2>&3)
    list=$(whiptail --title "Input Box" --inputbox "Please select the number of recommended movies" 10 60 3>&1 1>&2 2>&3)
    
    # 查看中间过程
    num=$(grep "sample" record | wc -l)
    if [ $num -ne 0 ]; then
         bash ./delete_file.sh sample
    fi
    # 分离数据
    #echo "start" > /dev/tcp/10.81.10.80/9527
    bash ./sam_gol_spl.sh $id $fileloc
    
    # 将文件存入DFS中
    bash ./throw_recom.sh $fileloc $block $rep
    
    # 进行商品推荐的map reduce程序
    bash ./jobtracker_recommend.sh sample $id $list
    
    # chunk位置信息回传
    bash ./recom_chunk_loc.sh

    # 结果整合
    bash ./reduce_recom.sh $neighbor $list $fileloc
   
    # chunk位置信息回传
    #bash ./recom_chunk_loc.sh

    whiptail --title "Prompt" --msgbox "Done!" 10 60
else
    whiptail --title "Prompt" --msgbox "Welcome to use next time" 10 60
    exit 1
fi
