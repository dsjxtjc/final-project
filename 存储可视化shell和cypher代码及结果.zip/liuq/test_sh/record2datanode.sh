#！/bin/bash

# record_name="${1}"

# printf '%s\n' id name | paste -sd ',' > datanode.csv

# cat $record_name | while read line; do 
	
# done