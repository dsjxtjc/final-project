#!/bin/bash

./taskAllocation.sh >runstate

if [[ `grep "thumm02" runstate` ]]; then
    echo `grep "thumm02" runstate`
    ssh thumm03 "scp thumm02:/data/dsjxtjc/2018211110/mapout0 /data/dsjxtjc/2018211110"
else
    datanode=`cat storage |grep d_0 |grep -v thumm02|awk -F':' 'NR==1{print $1}'`
    echo "thumm02 failed, we will assign the d_0 to $datanode to process"
    ssh $datanode "./mapper.py -i d_0 -o mapout0 -n $datanode"
    ssh thumm03 "scp $datanode:/data/dsjxtjc/2018211110/mapout0 /data/dsjxtjc/2018211110"
fi

if [[ `grep "thumm03" runstate` ]]; then
    echo `grep "thumm03" runstate`
fi

if [[ `grep "thumm04" runstate` ]]; then
    echo `grep "thumm04" runstate`
    ssh thumm03 "scp thumm04:/data/dsjxtjc/2018211110/mapout2 /data/dsjxtjc/2018211110"
else
    datanode=`cat storage |grep d_2 |grep -v thumm04|awk -F':' 'NR==1{print $1}'`
    echo "thumm04 failed, we will assign the d_2 to $datanode to process"
    ssh $datanode "./mapper.py -i d_2 -o mapout2 -n $datanode"
    ssh thumm03 "scp $datanode:/data/dsjxtjc/2018211110/mapout2 /data/dsjxtjc/2018211110"
fi

if [[ `grep "thumm05" runstate` ]]; then
    echo `grep "thumm05" runstate`
    ssh thumm03 "scp thumm05:/data/dsjxtjc/2018211110/mapout3 /data/dsjxtjc/2018211110"
else
    datanode=`cat storage |grep d_3 |grep -v thumm05|awk -F':' 'NR==1{print $1}'`
    echo "thumm05 failed, we will assign the d_3 to $datanode to process"
    ssh $datanode "./mapper.py -i d_3 -o mapout3 -n $datanode"
    ssh thumm03 "scp $datanode:/data/dsjxtjc/2018211110/mapout3 /data/dsjxtjc/2018211110"
fi

ssh thumm03 ./reducer.py
scp thumm03:/data/dsjxtjc/2018211110/result /home/dsjxtjc/2018211110
cat result


