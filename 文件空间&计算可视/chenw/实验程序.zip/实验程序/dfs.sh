#!/bin/bash

split -l 50000000 d.txt -d -a 1 d_
datanode=(thumm02 thumm03 thumm04 thumm05)
data=(d_0 d_1 d_2 d_3)

for((i=0;i<3*${#data[@]};i++))
do
	scp ${data[i/3]} ${datanode[i%4]}:/data/dsjxtjc/2018211110
	# echo ${datanode[i%4]} ${data[i/3]} 
	if [[ $((i%4)) == 0 ]]; then
		thumm02=(${thumm02[@]} ${data[i/3]})
	elif [[ $((i%4)) == 1 ]]; then
		thumm03=(${thumm03[@]} ${data[i/3]})
	elif [[ $((i%4)) == 2 ]]; then
		thumm04=(${thumm04[@]} ${data[i/3]})
	elif [[ $((i%4)) == 3 ]]; then
		thumm05=(${thumm05[@]} ${data[i/3]})
	else
		echo "error:something wrong!!!"
	fi
done
echo "d.txt:${data[@]}" >> partition
echo "thumm02:/data/dsjxtjc/2018211110/ ${thumm02[@]}" >> storage
echo "thumm03:/data/dsjxtjc/2018211110/ ${thumm03[@]}" >> storage
echo "thumm04:/data/dsjxtjc/2018211110/ ${thumm04[@]}" >> storage
echo "thumm05:/data/dsjxtjc/2018211110/ ${thumm05[@]}" >> storage
