#!/bin/bash


if [[ `cat partition |awk -F':' '{print $1}'|grep "^$1$"` ]]; then
    len=`cat partition |awk -F':' '{print $2}'|awk '{print NF}'`
    for((i=1;i<=$len;i++))
    do
        eval d$((i-1))=`cat partition |awk -F':' '{print $2}'|awk -v t=$i '{print $t}'`
        #eval echo \$d$((i-1))
        eval location$((i-1))=`cat storage |grep \$d$((i-1))|awk 'NR==1{print $1}'`
        #eval echo \$location$((i-1))
    done
    if [[ $2 ]]; then
        scp $location0$d0 $2
        scp $location1$d1 $2
        scp $location2$d2 $2
        scp $location3$d3 $2
        cat $2/$d0 $2/$d1 $2/$d2 $2/$d3 > $2/d.txt
        rm $2/$d0 $2/$d1 $2/$d2 $2/$d3
        echo "download complete!"
    else
        scp $location0$d0 /home/dsjxtjc/2018211110
        scp $location1$d1 /home/dsjxtjc/2018211110
        scp $location2$d2 /home/dsjxtjc/2018211110
        scp $location3$d3 /home/dsjxtjc/2018211110
        cat $d0 $d1 $d2 $d3 > d.txt
        rm $d0 $d1 $d2 $d3
        echo "download complete!"
    fi
else
    echo "the file doesn't exist, please check !"
    echo "the list of files is as follows:"
    cat partition |awk -F':' '{print $1}'
fi


