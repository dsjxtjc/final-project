#!/usr/bin/python
import random

f=open('d.txt','w')
for i in range(2*10**8):
    n=random.uniform(1,100)
    f.write(str(n)+'\n')
f.close()