#!/usr/bin/env python
#coding=utf-8
import sys, getopt

inputfile = ""
outputfile = ""
taskTracker = ""
path = "/data/dsjxtjc/2018211110/"
try:
	opts, args = getopt.getopt(sys.argv[1:], "hi:o:n:")
except getopt.GetoptError:
	print('<scriptfile> -i <inputfile> -o <outputfile> -n <taskTrackerName>')
	sys.exit()
for op, value in opts:
    if op == "-i":
        inputfile = value
    elif op == "-o":
        outputfile = value
    elif op == "-n":
        taskTracker = value
    elif op == "-h":
        print('<scriptfile> -i <inputfile> -o <outputfile> -n <taskTrackerName>')
        sys.exit()


n, sum1, sum2 = 0, 0.0, 0.0
with open(path+inputfile, 'r') as f:
	for line in f:
		sum1 += float(line)
		sum2 += float(line)**2
		n = n+1

with open(path+outputfile, 'w') as f:
	f.write(str(n)+' '+str(sum1)+' '+str(sum2)+'\n')

print(taskTracker+" has processed the file "+inputfile)
