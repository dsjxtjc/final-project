#!/bin/bash

taskTracker=(thumm02 thumm03 thumm04 thumm05)
for i in ${taskTracker[@]}
do
        scp mapper.py $i:/home/dsjxtjc/2018211110
done
scp reducer.py thumm03:/home/dsjxtjc/2018211110


ssh thumm02 ./mapper.py -i d_0 -o mapout0 -n thumm02 &
ssh thumm03 ./mapper.py -i d_1 -o mapout1 -n thumm03 &
ssh thumm04 ./mapper.py -i d_2 -o mapout2 -n thumm04 &
ssh thumm05 ./mapper.py -i d_3 -o mapout3 -n thumm05 &
wait

ssh thumm03 "scp thumm02:/data/dsjxtjc/2018211110/mapout0 /data/dsjxtjc/2018211110"
ssh thumm03 "scp thumm04:/data/dsjxtjc/2018211110/mapout2 /data/dsjxtjc/2018211110"
ssh thumm03 "scp thumm05:/data/dsjxtjc/2018211110/mapout3 /data/dsjxtjc/2018211110"
ssh thumm03 ./reducer.py
scp thumm03:/data/dsjxtjc/2018211110/result /home/dsjxtjc/2018211110
cat result
