#!/usr/bin/env python
#coding=utf-8

n, sum1, sum2 = 0, 0.0, 0.0
mapout = ['mapout0', 'mapout1', 'mapout2', 'mapout3']
path = "/data/dsjxtjc/2018211110/"
for file in mapout:
	with open(path+file, 'r') as f:
		for line in f:
			line = line.split(' ')
			n += float(line[0])
			sum1 += float(line[1])
			sum2 += float(line[2])

mean = sum1/n
var  = sum2/n-mean**2

with open(path+'result', 'w') as f:
	f.write('Mean:'+str(mean)+'\t'+'Variance:'+str(var)+'\n')
